package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.StudentBean;
import com.cg.dao.StudentDao;
import com.cg.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService {

	
	public boolean isValid(StudentBean bean) {

		
		
		return false;
	}

	
	public StudentBean addStudent(StudentBean bean) {

		StudentDao dao=new StudentDaoImpl();

		return dao.addStudent(bean);
	}


	
	public List<StudentBean> getStuDetails(List<StudentBean> bean) {
	    bean=new ArrayList();
		StudentDao dao=new StudentDaoImpl();

		return dao.getStuDetails(bean);
	}

}
