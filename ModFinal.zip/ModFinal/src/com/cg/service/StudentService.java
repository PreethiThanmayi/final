package com.cg.service;

import java.util.List;

import com.cg.bean.StudentBean;

public interface StudentService {

	boolean isValid(StudentBean bean);

	StudentBean addStudent(StudentBean bean);

	List<StudentBean> getStuDetails(List<StudentBean> bean);

}
