package com.cg.dao;

import java.util.List;

import com.cg.bean.StudentBean;

public interface StudentDao {

	StudentBean addStudent(StudentBean bean);

	List<StudentBean> getStuDetails(List<StudentBean> bean);

}
