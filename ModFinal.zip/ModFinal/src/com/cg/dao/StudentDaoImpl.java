
package com.cg.dao;

import java.util.List;

import com.cg.bean.StudentBean;

public class StudentDaoImpl implements StudentDao{

	
	public StudentBean addStudent(StudentBean bean) {

		
		
		return null;
	}

	
	public List<StudentBean> getStuDetails(List<StudentBean> bean) {
		
		
		return null;
	}

}
