package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.StudentBean;
import com.cg.exception.StudentException;
import com.cg.service.StudentService;
import com.cg.service.StudentServiceImpl;

public class StudentMain {
	static StudentBean bean=new StudentBean();
	static StudentService service=null;
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) throws StudentException {
		
		
		
		StudentBean stuId=null;
		int choice=0;
		System.out.println("menu");
		System.out.println("1.store student details");
		System.out.println("2.get student details");
		System.out.println("3.get student details by id");
		System.out.println("4.update student details");
		System.out.println("5.delete student details");
		System.out.println("6.exit");
		
		while(true)
		{
			System.out.println("enter choice");
			sc.nextInt();
			switch(choice)
			{
			
			case 1://store stu details	
			try
			{
				if(stuId==null)
				{
					bean=populateMain(bean);
					service =new StudentServiceImpl();
					stuId=service.addStudent(bean);
					System.out.println("details are successfully entered");
					System.out.println(bean);

				}
				
				else
				{
					System.out.println("cannot enter details");
				}
				
			}
			catch(Exception se)
			{
				throw new StudentException(se.getMessage());
			}
			
			break;
			
			
			case 2://get stu details
				
				try
				{
					System.out.println("students details are :");
					List<StudentBean> bean=new ArrayList();
					bean=service.getStuDetails(bean);
					System.out.println(bean);
				}
				catch(Exception e)
				{
					throw new StudentException(e.getMessage());
				}
				
		}
		
		
		}
		
	}

	private static StudentBean populateMain(StudentBean bean) {

		System.out.println("enter name");
		String name=sc.next();
		bean.setSname(name);
		
		System.out.println("enter student number");
		String num=sc.next();
		bean.setSnum(num);
		
		System.out.println("enter marks");
		int marks=sc.nextInt();
		bean.setMarks(marks);
		
		if(service.isValid(bean))
		{
			
		}
		
		
		
		return bean;
	}
	
}
